//1
let num1 = Number(prompt("Введите число для проверки деления на 7:"))
function checkElem(num){
    console.log(num % 7 == 0)
}
checkElem(num1)

//2
let n = Number(prompt("Введите число на которое будем умножать массив:"))
function changeElem(array, n){
    let newArray = []
    for(let i = 0; i < array.length; i++){
        newArray[i] = array[i] * n
    }
    return newArray
}
let array = [1,2,3,4]
let result = changeElem(array,n)
console.log(result)

//3
let arrayLength = Number(prompt("Сколько элементов будет в массиве строк?"))
let array2 = []
for(let i = 0; i < arrayLength; i++){
    array2[i] = prompt(`Введите ${i+1} элемент массива:`)
}
function sumElems(array){
    let sum = 0
    for(let i = 0; i < array.length; i++){
        let num = Number(array[i])
        if(!isNaN(num)){
            sum = sum + num
        }
    }
    return sum
}
let result2 = sumElems(array2)
console.log("Исходный массив:", array2)
console.log("Сумма чисел:", result2)

//4
let arrayLength2 = Number(prompt("Сколько элементов будет в массиве для переворота?"))
let array3 = []
for(let i = 0; i < arrayLength2; i++){
    array3[i] = prompt(`Введите ${i+1} элемент массива:`)
}
function reverseIndex(array){
    let newArray = []
    for(let i = array.length - 1; i >= 0; i--){
        newArray.push(array[i])
    }
    console.log("Исходный массив:", array)
    console.log("Перевернутый массив:", newArray)
}
reverseIndex(array3)

//5
let arrayLength3 = Number(prompt("Сколько элементов будет в массиве для проверки?"))
let array4 = []
for(let i = 0; i < arrayLength3; i++){
    array4[i] = Number(prompt(`Введите ${i+1} число:`))
}
let searchNum = Number(prompt("Какое число будем искать в массиве?"))
function checkElemCallback(array, callback){
    for(let i = 0; i < array.length; i++){
        if(callback(array[i]) == true){
            return true
        }
    }
    return false
}
let result3 = checkElemCallback(array4, (elem) => elem == searchNum)
console.log("Массив:", array4)
console.log("Ищем число", searchNum, ":", result3)